from .shared.CommonUtil import CommonUtil
from .config import app_config

#common = CommonUtil('development')

